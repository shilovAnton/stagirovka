﻿namespace Microsoft.Extensions.Logging
{
    public static class LoggerFields
    {
        public const string
            CorrelationId = "correlationId",
            AgencyId = "agencyId",
            AgentId = "agentId";
    }
}
